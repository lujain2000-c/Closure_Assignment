//
//  ContentView.swift
//  Text
//
//  Created by لجين إبراهيم الكنهل on 24/10/1444 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "person")
                .resizable()
                .padding([.top, .leading, .bottom],11.0)
                .frame(width: 150.0, height: 150.0)
                .background(Color.red)
                .cornerRadius(100)
                
                
            Text("Lujain Ibraheem".capitalized)
                .foregroundColor(.black)
                .font(.system(size: 30, weight: .ultraLight, design: .serif))
                //.font(Font.custom("SignPainter", size: 40))
                .background(Color.white)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
