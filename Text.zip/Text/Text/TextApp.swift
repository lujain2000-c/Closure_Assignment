//
//  TextApp.swift
//  Text
//
//  Created by لجين إبراهيم الكنهل on 24/10/1444 AH.
//

import SwiftUI

@main
struct TextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
